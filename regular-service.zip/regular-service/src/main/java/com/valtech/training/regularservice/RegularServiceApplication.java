package com.valtech.training.regularservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegularServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegularServiceApplication.class, args);
	}

}
